### 1、使用技术

#### 1.1、前端

**==Vue==+Vuex+router + ==axios==  + Element UI  +Iview**

- **==Vue==**:前端框架
- **Vuex**：Vue组件，全局数据存储与处理
- **router**：Vue组件，Vue的路由技术
- **==axios==**：基于ajax的JavaScript 异步请求库
- **Element UI**：基于Vue的UI库
- **iview**：基于Vue的UI库

#### 1.2、后端

**Node.js +MySQL + express**

- **Node.js**：JavaScript语言的后端运行库
- **MySQL** ：nodejs的模块，操作mysql数据库
- **express**： nodejs模块，服务器框架，用于接受请求数据，访问数据



### 2、主要代码

#### 2.1、前端

`axios请求`

```javascript
axios({
          url: "http://127.0.0.1:8090/ShoppingCart/insert",
          method: "POST",
          data: {
            Hno: this.$store.state.HeaderView.LoginStatus.user_id,
            Sno: this.goods.id,
          },
        }).then(
          (res) => {
            console.log(res.data);
            if(res.data.status === 200){
              this.$message.success("添加成功");
            }else {
              this.$message.error("添加失败");
            }
          },
          (err) => {
            console.log(err);
            this.$message.error("添加失败");
          }
        );
```



`Vue声明周期使用`

```javascript
if (
    this.$store.state.HeaderView.LoginStatus.status &&
    this.$store.state.HeaderView.LoginStatus.user === "manager"
) {
  console.log()
} else {
  this.$message.error("非管理员禁止操作!")
  this.$router.push({
    path: "/"
  })
}
```

> 主要用途:
>
> 使用声明周期,在不同的生命周期判断当前用户权限,对于不同的操作实现不同的管理



`Vue 入口函数`

```javascript
import Vue from 'vue'

import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';

import iview from 'iview'
import 'iview/dist/styles/iview.css'

import store from './store';
import VueRouter from 'vue-router'
import router from './router';

import App from './App.vue'

// 关闭生产提示
Vue.config.productionTip = false

Vue.use(ElementUI);
Vue.use(iview)
Vue.use(VueRouter)

new Vue({
  store,
  router,
  render: h => h(App),
}).$mount('#app')



```



`Element UI的使用`

```vue
<div class="login_view">
      <el-form
        :model="ruleForm"
        :rules="rules"
        ref="ruleForm"
        label-width="100px"
        class="demo-ruleForm"
      >
        <el-form-item label="用户名" prop="name">
          <el-input v-model="ruleForm.name"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="ruleForm.password" type="password"></el-input>
        </el-form-item>
      </el-form>

      <el-button
        style="float: right; margin-left: 40px"
        type="warning"
        plain
        @click="goToRegister"
        >没有账号，注册</el-button
      >
      <el-button style="float: right" type="primary" @click="loginMember"
        >登陆</el-button
      >
    </div>
```



`iview的使用`

```vue
<Grid square
    >
      <GridItem v-for="(item,index) in pictures" :key="index">
        <img :src="item" alt="" width="20%" height="20%"
        style="border-radius: 15px;"
        >
      </GridItem>
    </Grid>
```



#### 2.2、后端

`nodejs的启动文件`

```javascript
/**
 * @name main
 * @author MateBook13
 * @description 2002
 * @date 2023/1/8
 */

const express = require('express');
const routerOne = require('./Server/Router/router.js')
const routerMember = require('./Server/Router/routerMember.js')
const routerManager = require('./Server/Router/routerManager.js')
const routerCommodity = require('./Server/Router/routerCommodity.js')
const routerShoppingCart = require('./Server/Router/routerShoppingCart.js')
const routerShopDingDan = require('./Server/Router/routerShopDingDan.js')
const routerObject = require('./Server/Router/routerObject.js')

const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.urlencoded({
    extended: false
}))
app.use(bodyParser.json())

app.use(cors())

app.use('/', routerOne)
app.use('/member', routerMember)
app.use('/manager', routerManager)
app.use('/routerCommodity', routerCommodity)
app.use('/ShoppingCart', routerShoppingCart)
app.use('/routerShopDingDan', routerShopDingDan)
app.use('/routerObject', routerObject)

app.use('/pictures',express.static('./Server/Temp'))//文件夹

app.listen(8090, function () {
    console.log("RUNNING!!");
})

```



`mysql数据库的操作`

```javascript
const mysql = require('mysql')
// mysql 配置信息
const config = {
    host: "rm-2ze81g5572t0v2231zo.mysql.rds.aliyuncs.com",
    user: "messi",
    password: "Xinan2002@",
    port: "3306",
    database: "mall_system"//需要操作的数据库
};
const db = mysql.createPool(config)

let sql = `SELECT *
FROM huiyuan;`;
    db.query(sql, (err, results) => {
        if (err) return console.log(err.message);
        res.send({
            status: 200,
            msg: "登陆成功",
            data: {
                status: "success",
                body: results
            }
        })
    })
```



`express的使用`

> express通过路由实现对不同请求的具体划分

```javascript
app.use('/', routerOne)
app.use('/member', routerMember)
app.use('/manager', routerManager)
app.use('/routerCommodity', routerCommodity)
app.use('/ShoppingCart', routerShoppingCart)
app.use('/routerShopDingDan', routerShopDingDan)
app.use('/routerObject', routerObject)
```



`数据的模拟请求`

> 使用 **ApiPost** 软件

**==（有图片）==**

`数据库的操作`

- 注册会员

  ```mysql
  -- 注册会员
  INSERT INTO huiyuan
  VALUES ('09010', '海贼', '21671', '12456464', '青海西宁');
  ```

- 查询商品

  ```mysql
  
  -- 查询商品
  SELECT shangpin.Sno, SZno, Sname, Sprice, Sintro, ob.picture_path
  FROM shangpin
           INNER JOIN object_pictures ob on shangpin.Sno = ob.Sno;
  
  ```

- 查询图片

  ```mysql
  -- 查询图片
  SELECT picture_path
  FROM object_pictures
  WHERE Sno = '01001';
  ```

- 模糊查询商品

  ```mysql
  -- 模糊查询商品
  SELECT *
  FROM shangpin
  WHERE Sname like '%老%';
  ```

- 查询购物车

  ```mysql
  -- 查询购物车
  SELECT *
  FROM shangpin
  WHERE Sno IN (SELECT Sno
               FROM gouwuche
               WHERE Hno = '13206'
  );
  ```

- 添加订单

  ```mysql
  -- 添加订单
  INSERT INTO dingdan (Hno, object_id, Ddate, Dtotal)
  VALUES ('13206','01001&01002',NOW(),345.78);
  ```

