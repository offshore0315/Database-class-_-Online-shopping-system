/**
 * @name baseUser
 * @author MateBook13
 * @description baseUser
 * @date 2023/1/8
 */
const mysql = require('mysql')
// mysql 配置信息
const config = {
    host: "rm-2ze81g5572t0v2231zo.mysql.rds.aliyuncs.com",
    user: "messi",
    password: "Xinan2002@",
    port: "3306",
    database: "mall_system"//需要操作的数据库
};

const db = mysql.createPool(config)

function selectMysql(connect) {
    let sql = `SHOW TABLES;`;
    connect.query(sql, (err, results) => {
        if (err) return console.log(err.message);
        console.log(results);
        closeMysql(connect)
    })
}

let student = {
    gride: 66,
    number: 33
};
function insertMySQL(connect, data) {
    // 需要插入的数据
    // 需要执行的SQL语句， 其他 ? 为占位符
    let sql = `INSERT INTO student(gride,number)
            VALUES(?,?);`;
    // 中间参数为需要替换 ？号的参数
    connect.query(sql, [data.gride, data.number], (err, results) => {
        if (err) return console.log(err.message);
        if (results.affectedRows === 1) {
            console.log('插入成功');
        }
        closeMysql(connect);
    })
}

function closeMysql(connect) {
    connect.end((err) => {
        if (err) {
            console.log('关闭失败');
        } else {
            console.log('MySQL已关闭');
        }
    })
}

// insertMySQL(db, student)
selectMysql(db);