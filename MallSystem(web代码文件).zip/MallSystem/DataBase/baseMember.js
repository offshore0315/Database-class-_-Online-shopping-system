/**
 * @name baseMember
 * @author MateBook13
 * @description baseMember
 * @date 2023/1/8
 */