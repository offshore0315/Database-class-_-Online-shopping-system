/**
 * @name baseShoppingCart
 * @author MateBook13
 * @description baseShoppingCart
 * @date 2023/1/8
 */