/**
 * @name test
 * @author MateBook13
 * @description test
 * @date 2023/1/14
 */
let arr=""
for(let i=0;i<5;i++){
    let ran = Math.floor((Math.random()*10) )
    arr+=ran;
}
console.log(arr)