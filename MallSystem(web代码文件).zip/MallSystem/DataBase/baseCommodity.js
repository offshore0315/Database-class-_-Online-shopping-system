/**
 * @name baseCommodity
 * @author MateBook13
 * @description baseCommodity
 * @date 2023/1/8
 */