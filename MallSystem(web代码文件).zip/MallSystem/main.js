/**
 * @name main
 * @author MateBook13
 * @description 2002
 * @date 2023/1/8
 */

const express = require('express');
const routerOne = require('./Server/Router/router.js')
const routerMember = require('./Server/Router/routerMember.js')
const routerManager = require('./Server/Router/routerManager.js')
const routerCommodity = require('./Server/Router/routerCommodity.js')
const routerShoppingCart = require('./Server/Router/routerShoppingCart.js')
const routerShopDingDan = require('./Server/Router/routerShopDingDan.js')
// const routerObject = require('./Server/Router/routerObject.js')

const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.urlencoded({
    extended: false,
}))
app.use(bodyParser.json())

app.use(cors())


app.use('/', routerOne)
app.use('/member', routerMember)
app.use('/manager', routerManager)
app.use('/routerCommodity', routerCommodity)
app.use('/ShoppingCart', routerShoppingCart)
app.use('/routerShopDingDan', routerShopDingDan)
// app.use('/routerObject', routerObject)

app.use('/pictures', express.static('./Server/Temp'))//文件夹

app.listen(8090, function () {
    console.log("RUNNING!!");
})
