<template>
  <div class="login">
    <div class="tag">
      <el-steps :active="active" finish-status="success">
        <el-step title="输入管理员账号"></el-step>
        <el-step title="输入管理员密码"></el-step>
        <el-step title="登陆使用管理员系统"></el-step>
      </el-steps>

      <el-button style="margin-top: 12px" @click="next">下一步</el-button>
    </div>
    <Alert show-icon style="margin-top: 10px">
      管理员登陆页面
      <template #icon>
        <Icon type="ios-bulb-outline"></Icon>
      </template>
      <template #desc>请使用用户名及密码登陆</template>
    </Alert>
    <div class="login_view">
      <el-form
        :model="ruleForm"
        :rules="rules"
        ref="ruleForm"
        label-width="100px"
        class="demo-ruleForm"
      >
        <el-form-item label="管理员账号" prop="number">
          <el-input v-model="ruleForm.number"></el-input>
        </el-form-item>
        <el-form-item label="管理员密码" prop="password">
          <el-input v-model="ruleForm.password" type="password"></el-input>
        </el-form-item>
      </el-form>

      <!-- <el-button
        style="float: right; margin-left: 40px"
        type="warning"
        plain
        @click="goToRegister"
        >没有账号，注册</el-button
      > -->
      <el-button style="float: right" type="primary" @click="loginManager"
        >登陆</el-button
      >
    </div>
    <div class="login_show">
      <span style="font-size: 16px; font-weight: bold">
        青青子衿，悠悠我心。<br />
        纵我不往，子宁不嗣音？<br />
        青青子佩，悠悠我思。<br />
        纵我不往，子宁不来？<br />
        挑兮达兮，在城阙兮。<br />
        一日不见，如三月兮。<br />
      </span>
      <el-divider content-position="right">《诗经·郑风·子衿》</el-divider>
    </div>
  </div>
</template>
  <script>
import axios from "axios";
export default {
  data() {
    return {
      ruleForm: {
        number: "",
        password: "",
        activeName: "1",
      },
      rules: {
        number: [
          { required: true, message: "请输入管理员账号", trigger: "blur" },
        ],
        password: [
          { required: true, message: "请输入管理员密码", trigger: "blur" },
        ],
      },
      active: 0,
    };
  },
  methods: {
    loginManager() {
      if (this.ruleForm.name != "" && this.ruleForm.password != "") {
        axios({
          method: "POST",
          url: "http://127.0.0.1:8090/manager/login",
          data: {
            number: this.ruleForm.number,
            password: this.ruleForm.password,
          },
        }).then(
          (res) => {
            console.log(res);
            if (res.data.data.status === "success") {
              this.$message.success("登陆成功");
              this.$store.commit("loginUser", {
                pwd: this.ruleForm.password,
                name: this.ruleForm.number,
                user: "manager",
                id: this.ruleForm.number,
              });
            } else {
              this.$message.error("管理员不存在或密码错误");
            }
          },
          (err) => {
            console.log(err);
          }
        );
      } else {
        this.$message.warning("不能为空");
      }
    },
    next() {
      if (this.active++ > 2) this.active = 0;
    },
  },
  mounted() {
    this.$store.commit("changePathCrumb", ["首页", "管理员登陆"]);
    if (this.$store.state.HeaderView.LoginStatus.status) {
      this.$notify({
        title: "错误",
        message: "请先退出当前登陆状态",
        offset: 150,
        type: "error",
        duration: 1000,
      });
      this.$message.warning("请先退出登陆");
      this.$confirm("是否退出当前登陆?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          this.$store.commit("logoutUser");
        })
        .catch(() => {
          this.$router.push({
            path: "/",
          });
        });
    }
  },
};
</script>
  
<style scoped>
.login {
  width: 80%;
  margin-left: 10%;
  margin-top: 50px;
}
.login_view {
  width: 60%;
  height: 100%;
  margin-left: 20%;
  margin-top: 5vh;
}
.login_show {
  width: 80%;
  margin-left: 10%;
  margin-top: 10vh;
}
.tag {
  width: 80%;
  margin-left: 10%;
}
</style>