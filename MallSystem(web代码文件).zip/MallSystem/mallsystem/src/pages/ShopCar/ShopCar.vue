<template>
  <div>
    <div class="deleteButton">
      <Affix
        :offset-top="50"
        style="margin-top: 10px; margin-left: 70px; display: inline-block"
      >
        <Tooltip content="清空购物车" placement="right">
          <el-badge :value="object.length" class="item">
            <el-button
              size="large"
              type="danger"
              plain
              @click.stop="deleteShopCar"
              >清空购物车</el-button
            >
          </el-badge>
        </Tooltip>
      </Affix>

      <Affix
        :offset-top="50"
        style="margin-top: 10px; margin-left: 100px; display: inline-block"
      >
        <Tooltip content="下单全部商品" placement="right">
          <el-badge :value="object.length" class="item">
            <el-button
              size="large"
              type="primary"
              plain
              @click.stop="paineShopCar"
              >下单全部商品</el-button
            >
          </el-badge>
        </Tooltip>
      </Affix>
    </div>
    <MerchandiseMenu
      v-for="(item, index) in object"
      :key="index"
      :object="item"
    />
  </div>
</template>

<script>
import MerchandiseMenu from "@/components/ShopCarMenu.vue";
import axios from "axios";
export default {
  data() {
    return {
      object: [],
    };
  },
  components: {
    MerchandiseMenu,
  },
  methods: {
    deleteShopCar() {
      this.$confirm("是否删除购物车中的全部物品", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          this.deleteBaseShopCar();
          this.$notify({
            title: "成功",
            message: "成功删除购物车",
            type: "success",
          });
          this.selectShopCar();
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },
    paineShopCar() {
      let total_price = 0;
      for (let i = 0; i < this.object.length; i++) {
        total_price = total_price + this.object[i].price;
      }
      this.$confirm("是否下单全部物品?"+"共需付 ￥"+total_price, "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          this.insertDingDan();
          this.deleteBaseShopCar();
          this.$notify({
            title: "成功",
            message: "成功下单",
            type: "success",
          });
          // this.selectShopCar();
          this.object = []
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消下单",
          });
        });
    },
    deleteBaseShopCar() {
      axios({
        url: "http://127.0.0.1:8090/ShoppingCart/delete",
        method: "POST",
        data: {
          Hno: this.$store.state.HeaderView.LoginStatus.user_id,
        },
      }).then(
        (res) => {
          console.log(res);
        },
        (err) => {
          console.log(err);
        }
      );
    },
    selectShopCar() {
      this.$store.commit("changePathCrumb", ["首页", "我的购物车"]);
      axios({
        url: "http://127.0.0.1:8090/ShoppingCart/select",
        method: "POST",
        data: {
          Hno: this.$store.state.HeaderView.LoginStatus.user_id,
        },
      }).then(
        (res) => {
          console.log(res);
          this.object = [];
          for (let index = 0; index < res.data.data.length; index++) {
            this.object.push({
              name: res.data.data[index].Sname,
              price: res.data.data[index].Sprice,
              introduce: res.data.data[index].Sintro,
              id: res.data.data[index].Sno,
              pictures: [],
            });
          }
          for (let index = 0; index < this.object.length; index++) {
            axios({
              url: "http://127.0.0.1:8090/routerCommodity/selectPictures",
              method: "POST",
              data: {
                number: this.object[index].id,
              },
            }).then(
              (res) => {
                for (let j = 0; j < res.data.data.length; j++) {
                  this.object[index].pictures.push(
                    res.data.data[j].picture_path
                  );
                }
              },
              (err) => {
                console.log(err);
              }
            );
          }
        },
        (err) => {
          console.log(err);
        }
      );
    },
    insertDingDan() {
      let _id = "";
      let total_price = 0;
      for (let i = 0; i < this.object.length; i++) {
        console.log(this.object[i].id);
        console.log(this.object[i].price);
        _id = _id + this.object[i].id + "&";
        total_price = total_price + this.object[i].price;
      }
      axios({
        url: "http://127.0.0.1:8090/ShoppingCart/insertDingDan",
        method: "POST",
        data: {
          Hno: this.$store.state.HeaderView.LoginStatus.user_id,
          object_id: _id,
          Dtotal: total_price,
        },
      }).then(
        (res) => {
          console.log(res);
        },
        (err) => {
          console.log(err);
        }
      );
    },
  },
  mounted() {
    if (
      (this.$store.state.HeaderView.LoginStatus.user === "" &&
        this.$store.state.HeaderView.LoginStatus.status) ||
      (this.$store.state.HeaderView.LoginStatus.user === "member" &&
        this.$store.state.HeaderView.LoginStatus.status)
    ) {
      this.selectShopCar();
    } else {
      this.$message.error("管理员不可使用或未登录");
      this.$router.push({
        path: "/",
      });
    }
  },
};
</script>

<style scoped>
.deleteButton {
  width: 100%;
  height: 50px;
}
</style>