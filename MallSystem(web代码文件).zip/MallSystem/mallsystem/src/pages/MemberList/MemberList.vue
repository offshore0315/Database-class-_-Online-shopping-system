<template>
  <div>
    <el-table
        :data="member"
        style="width: 99%; margin-left: 0.5%; border-radius: 10px; margin-top: 5px;"
        stripe
        height="820"
    >
      <el-table-column
          prop="Hno"
          label="ID号"
          width="300">
      </el-table-column>
      <el-table-column
          prop="Hname"
          label="姓名"
          width="300">
      </el-table-column>
      <el-table-column
          prop="Htel"
          label="电话号"
          width="300">
      </el-table-column>
      <el-table-column
          prop="Hadd"
          label="地址">
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: "MemberList",
  data() {
    return {
      member: [],
    }
  },
  mounted() {
    if (this.$store.state.HeaderView.LoginStatus.status &&
        this.$store.state.HeaderView.LoginStatus.user === "manager") {
      axios({
        url: "http://127.0.0.1:8090/member/select",
        method: "POST",
        data: {}
      }).then(
          (res) => {
            console.log(res.data.data.body)
            this.member = res.data.data.body
          },
          (err) => {
            console.log(err)
          }
      )
    } else {
      this.$message.error("无权限查看")
      this.$router.push({
        path: "/"
      })
    }
  }
}
</script>

<style scoped>

</style>