<template>
  <div>
    <div v-for="(item,index) in object_ding_dan" :key="index">
      <el-descriptions class="margin-top" title="订单列表" :column="3" :size="size" border
                       style="width: 96%; margin-left: 2%;border-radius: 5px;">
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-user"></i>
            用户名
          </template>
          {{ name }}
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-mobile-phone"></i>
            会员号
          </template>
          <el-tag type="warning">
            {{ number_id }}
          </el-tag>

        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-location-outline"></i>
            订单时间
          </template>
          {{ item.date }}
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-tickets"></i>
            总价
          </template>
          <el-tag size="small" type="danger">
            ￥{{ item.total }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-office-building"></i>
            商品编号
          </template>
          <el-tag
              type="success"
              v-for="(object_id,i) in item.object_id"
              :key="i"
              style="margin-right: 3px;"
          >{{ object_id }}
          </el-tag>
        </el-descriptions-item>
      </el-descriptions>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      object_ding_dan: [],
      name: this.$store.state.HeaderView.LoginStatus.user_name,
      number_id: this.$store.state.HeaderView.LoginStatus.user_id,
    }
  },
  mounted() {
    if (
        this.$store.state.HeaderView.LoginStatus.user === "" ||
        this.$store.state.HeaderView.LoginStatus.user === "member"
    ) {
      axios({
        url: "http://127.0.0.1:8090/routerShopDingDan/select",
        method: "POST",
        data: {
          Hno: this.$store.state.HeaderView.LoginStatus.user_id
        }
      }).then(
          (res) => {
            console.log(res.data.data)
            for (let i = 0; i < res.data.data.length; i++) {
              let arr = res.data.data[i].object_id.split("&")
              let newArr = []
              for (let j = 0; j < arr.length - 1; j++) {
                newArr[j] = arr[j]
              }
              this.object_ding_dan.push({
                date: res.data.data[i].Ddate,
                total: res.data.data[i].Dtotal,
                object_id: newArr,
              })
            }
          }, (err) => {
            console.log(err)
          }
      )
    }else {
      this.$message.error("管理员或未登录不可使用")
    }

  }
}
</script>

<style scoped>

</style>