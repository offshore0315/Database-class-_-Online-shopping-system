<template>
  <div class="ShopView">
    <div style="height: 50px">
      <!-- <Button @click="drawer = true" type="primary">Open</Button> -->
      <Input
        v-model="lookValue"
        placeholder="Enter something..."
        clearable
        style="
          width: 300px;
          margin-left: 20px;
          margin-top: 10px;
          font-size: 16px;
          font-weight: 700;
        "
      />
      <Button @click="lookLike" type="success" style="margin-top: 10px"
        >搜索</Button
      >

      <Select
        v-model="model"
        style="width: 200px; margin-left: 50px; margin-top: 10px"
        prefix="ios-home"
        @on-change="selectLabel"
      >
        <Option value="normal" label="默认">
          <span>默认</span>
          <span style="float: right; color: #ccc">默认</span>
        </Option>
        <Option value="ASC" label="升序">
          <span>升序</span>
          <span style="float: right; color: #ccc">价格身高</span>
        </Option>
        <Option value="DESC" label="降序">
          <span>降序</span>
          <span style="float: right; color: #ccc">价格降低</span>
        </Option>
      </Select>
    </div>

    <MerchandiseMenu
      v-for="(item, index) in object"
      :key="index"
      :object="item"
    />
  </div>
</template>
<script>
import MerchandiseMenu from "@/components/MerchandiseMenu.vue";
import axios from "axios";
export default {
  data() {
    return {
      object: [],
      lookValue: "",
      model: "",
    };
  },
  components: {
    MerchandiseMenu,
  },
  methods: {
    selectObject(sort) {
      axios({
        url: "http://127.0.0.1:8090/routerCommodity/select",
        method: "POST",
        data: {
          sort,
        },
      }).then(
        (res) => {
          this.object = [];
          for (let index = 0; index < res.data.data.length; index++) {
            this.object.push({
              name: res.data.data[index].Sname,
              price: res.data.data[index].Sprice,
              introduce: res.data.data[index].Sintro,
              id: res.data.data[index].Sno,
              pictures: [],
            });
          }
          for (let index = 0; index < this.object.length; index++) {
            axios({
              url: "http://127.0.0.1:8090/routerCommodity/selectPictures",
              method: "POST",
              data: {
                number: this.object[index].id,
              },
            }).then(
              (res) => {
                for (let j = 0; j < res.data.data.length; j++) {
                  this.object[index].pictures.push(
                    res.data.data[j].picture_path
                  );
                }
              },
              (err) => {
                console.log(err);
              }
            );
          }
        },
        (err) => {
          console.log(err);
        }
      );
    },
    selectLabel(value) {
      console.log(value);
      this.selectObject(value);
    },
    lookLike() {
      axios({
        url: "http://127.0.0.1:8090/routerCommodity/selectLike",
        method: "POST",
        data: {
          like:this.lookValue,
        },
      }).then(
        (res) => {
          console.log(res);
          this.object = [];
          for (let index = 0; index < res.data.data.length; index++) {
            this.object.push({
              name: res.data.data[index].Sname,
              price: res.data.data[index].Sprice,
              introduce: res.data.data[index].Sintro,
              id: res.data.data[index].Sno,
              pictures: [],
            });
          }
          for (let index = 0; index < this.object.length; index++) {
            axios({
              url: "http://127.0.0.1:8090/routerCommodity/selectPictures",
              method: "POST",
              data: {
                number: this.object[index].id,
              },
            }).then(
              (res) => {
                for (let j = 0; j < res.data.data.length; j++) {
                  this.object[index].pictures.push(
                    res.data.data[j].picture_path
                  );
                }
              },
              (err) => {
                console.log(err);
              }
            );
          }
        },
        (err) => {
          console.log(err);
        }
      );
    },
  },
  mounted() {
    if (
      this.$store.state.HeaderView.LoginStatus.user === "" ||
      this.$store.state.HeaderView.LoginStatus.user === "member"
    ) {
      this.selectObject("normal");
      // 请求图片

      this.$store.commit("changePathCrumb", ["首页", "商品浏览"]);
    } else {
      this.$message.error("管理员不可使用");
      this.$router.push({
        path: "/",
      });
    }
  },
};
</script>

<style scoped>
.ShopView {
  overflow: auto;
  height: 100%;
}
</style>