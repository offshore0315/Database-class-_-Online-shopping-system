<template>
  <el-empty description="商城系统" style="margin-top: 28vh"></el-empty>
</template>

<script>
export default {
  name: "IndexPage",
  mounted() {
    this.$store.commit("changePathCrumb", ["首页"]);
  },
}
</script>

<style scoped>

</style>