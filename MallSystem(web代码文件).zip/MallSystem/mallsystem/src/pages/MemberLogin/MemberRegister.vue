<template>
  <div class="login">
    <el-steps :active="2" simple>
      <el-step title="注册" icon="el-icon-edit"></el-step>
      <el-step title="登陆" icon="el-icon-upload"></el-step>
      <el-step title="使用" icon="el-icon-picture"></el-step>
    </el-steps>
    <Alert show-icon style="margin-top: 10px" type="warning">
      注册页面
      <template #desc>请使用详细信息注册新的商城会员</template>
    </Alert>
    <div class="login_view">
      <el-form
        :model="ruleForm"
        :rules="rules"
        ref="ruleForm"
        label-width="100px"
        class="demo-ruleForm"
      >
        <el-form-item label="用户名" prop="name">
          <el-input v-model="ruleForm.name"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="ruleForm.password" type="password"></el-input>
        </el-form-item>
        <el-form-item label="确认密码" prop="password_1">
          <el-input v-model="ruleForm.password_1" type="password"></el-input>
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input v-model="ruleForm.phone"></el-input>
        </el-form-item>
        <el-form-item label="收货地址" prop="address">
          <el-input v-model="ruleForm.address"></el-input>
        </el-form-item>
      </el-form>
      <el-button
        style="float: right; margin-left: 40px"
        type="warning"
        plain
        @click="goToLogin"
        >返回登陆</el-button
      >
      <el-button style="float: right" type="primary" @click="registerMember"
        >注册</el-button
      >
    </div>
    <div class="login_show">
      <span style="font-size: 16px; font-weight: bold">
        青青子衿，悠悠我心。<br />
        纵我不往，子宁不嗣音？<br />
        青青子佩，悠悠我思。<br />
        纵我不往，子宁不来？<br />
        挑兮达兮，在城阙兮。<br />
        一日不见，如三月兮。<br />
      </span>
      <el-divider content-position="right">《诗经·郑风·子衿》</el-divider>
    </div>
  </div>
</template>
<script>
import axios from "axios";

export default {
  data() {
    return {
      ruleForm: {
        name: "",
        password: "",
        password_1: "",
        phone: "",
        address: "",
        activeName: "1",
      },
      rules: {
        name: [{ required: true, message: "请输入用户名", trigger: "blur" }],
        password: [{ required: true, message: "请输入密码", trigger: "blur" }],
        password_1: [
          { required: true, message: "请输入密码", trigger: "blur" },
        ],
        phone: [{ required: true, message: "请输入手机号", trigger: "blur" }],
        address: [
          { required: true, message: "请输入收货地址", trigger: "blur" },
        ],
      },
    };
  },
  methods: {
    goToLogin() {
      this.$router.push({
        path: "/memberLogin",
      });
    },
    registerMember() {
      if (
        this.ruleForm.password === this.ruleForm.password_1 &&
        this.ruleForm.password_1 !== "" &&
        this.ruleForm.name !== "" &&
        this.ruleForm.phone !== "" &&
        this.ruleForm.address !== "" &&
        this.ruleForm.password !== ""
      ) {
        axios({
          method: "POST",
          url: "http://127.0.0.1:8090/member/register",
          data: {
            Hname: this.ruleForm.name,
            Hpassword: this.ruleForm.password,
            Htel: this.ruleForm.phone,
            Hadd: this.ruleForm.address,
          },
        }).then(
          (res) => {
            if (res.data.data.status === "success") {
              this.$notify({
                title: "注册成功",
                message: "你已成功注册会员，正在跳转登陆页面",
                type: "success",
              });
            } else {
              this.$message.error("注册失败（或重复注册）");
            }
          },
          (err) => {
            console.log(err);
          }
        );
      } else {
        this.$message.error("前后密码不一致");
      }
    },
  },
  mounted() {
    this.$store.commit("changePathCrumb", ["首页", "管理员登陆"]);
    if (this.$store.state.HeaderView.LoginStatus.status) {
      this.$notify({
        title: "错误",
        message: "请先退出当前登陆状态",
        offset: 150,
        type: "error",
        duration: 1000,
      });
      this.$message.warning("请先退出登陆");
      this.$router.push({
        path: "/",
      });
      this.$confirm("是否退出当前登陆?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          this.$store.commit("logoutUser");
        })
        .catch(() => {
          this.$router.push({
            path: "/",
          });
        });
    }
  },
};
</script>

<style scoped>
.login {
  width: 80%;
  margin-left: 10%;
  margin-top: 50px;
}

.login_view {
  width: 60%;
  height: 100%;
  margin-left: 20%;
  margin-top: 5vh;
}

.login_show {
  width: 80%;
  margin-left: 10%;
  margin-top: 10vh;
}
</style>