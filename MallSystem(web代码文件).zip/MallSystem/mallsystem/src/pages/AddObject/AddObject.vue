<template>
  <div>
    <div class="m_input">
      <el-form
          :model="ruleForm"
          :rules="rules"
          ref="ruleForm"
          label-width="100px"
          class="demo-ruleForm"
      >
        <el-form-item label="商品名称" prop="name">
          <el-input v-model="ruleForm.name"></el-input>
        </el-form-item>
        <el-form-item label="商品价格" prop="price">
          <el-input v-model="ruleForm.price"></el-input>
        </el-form-item>
        <el-form-item label="商品描述" prop="introduce">
          <el-input v-model="ruleForm.introduce" type="textarea"></el-input>
        </el-form-item>
      </el-form>
    </div>


    <br/>

    <Grid square
    >
      <GridItem v-for="(item,index) in pictures" :key="index">
        <img :src="item" alt="" width="20%" height="20%"
             style="border-radius: 15px;"
        >
      </GridItem>
    </Grid>
    <el-button
    style="margin-left: 50%;"
    >上传图片</el-button>
    <el-button>添加</el-button>
  </div>
</template>

<script>
// import axios from 'axios'

export default {
  name: "AddObject",
  data() {
    return {
      ruleForm: {
        name: "",
        price: "",
        introduce: ""
      },
      rules: {
        name: [{required: true, message: "请输入用户名", trigger: "blur"}],
        price: [{required: true, message: "请输入商品价格", trigger: "blur"}],
        introduce: [{required: true, message: "请输入描述", trigger: "blur"}],
      },
      pictures: [
        // "http://localhost:8090/pictures/2023011519271.jpg",
        // "http://localhost:8090/pictures/2023011519271.jpg",
        // "http://localhost:8090/pictures/2023011519271.jpg",
        // "http://localhost:8090/pictures/2023011519271.jpg",
        // "http://localhost:8090/pictures/2023011519271.jpg"
      ],
      dialogImageUrl: '',
      dialogVisible: false
    }
  },
  methods: {
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    }
  },
  mounted() {
    if (
        this.$store.state.HeaderView.LoginStatus.status &&
        this.$store.state.HeaderView.LoginStatus.user === "manager"
    ) {
      console.log()
    } else {
      this.$message.error("非管理员禁止操作!")
      this.$router.push({
        path: "/"
      })
    }
  }
}
</script>

<style scoped>
.m_input {
  /*display: inline-block;*/
  width: 70%;
  margin-left: 15%;
  margin-top: 100px;
}
</style>