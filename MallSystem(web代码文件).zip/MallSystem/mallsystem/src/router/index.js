/**
 * @name index
 * @author MateBook13
 * @description index
 * @date 2023/1/12
 */
import VueRouter from 'vue-router'

import IndexPage from '@/pages/index/IndexPage.vue'
import MemberLogin from '@/pages/MemberLogin/MemberLogin.vue'
import MemberRegister from '@/pages/MemberLogin/MemberRegister.vue'
import ManagerLogin from '@/pages/Manager/ManagerLogin.vue'
import ShopView from '@/pages/ShopView/ShopView.vue'
import ShopCar from '@/pages/ShopCar/ShopCar.vue'
import DingDanShow from '@/pages/DingDan/DingDanShow.vue'
import MemberList from '@/pages/MemberList/MemberList.vue'
import AddObject from '@/pages/AddObject/AddObject.vue'
export default new VueRouter({
    routes:[
        {
            path:"/",
            component:IndexPage
        },
        {
            path:"/memberLogin",
            component:MemberLogin,
        },
        {
            path:"/memberRegister",
            component:MemberRegister,
        },
        {
            path:"/managerLogin",
            component:ManagerLogin,
        },
        {
            path:"/shopView",
            component:ShopView,
        },
        {
            path:"/shopCar",
            component:ShopCar,
        },
        {
            path:"/dingDanShow",
            component:DingDanShow,
        },
        {
            path:"/memberList",
            component:MemberList,
        },
        {
            path:"/addObject",
            component:AddObject,
        }
    ]
})