<template>
  <div id="app">
    <Layout>
      <Header class="layout-header">
        <HeaderView style="margin-top: -12px"/>
      </Header>
      <Layout>
        <Sider class="layout-sider" hide-trigger>
          <NavBar/>
        </Sider>
        <Content class="layout-content">
          <router-view></router-view>
        </Content>
      </Layout>
    </Layout>
  </div>
</template>

<script>
import HeaderView from '@/components/HeaderView.vue'
import NavBar from '@/components/NavBar.vue'

export default {
  name: 'App',
  components: {
    HeaderView,
    NavBar
  }
}
</script>

<style scoped>
.layout-header {
  height: 50px;
  background-color: aliceblue;
  border-radius: 5px;
}
.layout-sider {
  height: calc(100vh - 50px);
  background-color: #ffffff;
  width: 10%;
}
.layout-content {
  height: calc(100vh - 50px);
  background-color: rgb(230, 238, 241);
  width: 90%;
}
</style>
