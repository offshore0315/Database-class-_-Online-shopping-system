import Vue from 'vue'

import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';

import iview from 'iview'
import 'iview/dist/styles/iview.css'

import store from './store';
import VueRouter from 'vue-router'
import router from './router';

import App from './App.vue'

// 关闭生产提示
Vue.config.productionTip = false

Vue.use(ElementUI);
Vue.use(iview)
Vue.use(VueRouter)

new Vue({
  store,
  router,
  render: h => h(App),
}).$mount('#app')


