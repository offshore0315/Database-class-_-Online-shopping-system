<template>
  <div>
    <!--    <PaneList/>-->
    <Menu theme="light"
          active-name="1"
          style="width: 100%;height: 100%; overflow-y: auto"
    >
      <MenuGroup title="商品中心">
        <MenuItem
            name="1"
            to="/shopView"
        >
          <Icon type="md-document"/>
          商品浏览
        </MenuItem>
        <MenuItem name="2">
          <Icon type="md-chatbubbles"/>
          商品推荐
        </MenuItem>
      </MenuGroup>
      <MenuGroup title="购物车管理">
        <MenuItem name="3" to="/ShopCar">
          <Icon type="md-document"
          />
          购物车
        </MenuItem>
      </MenuGroup>
      <MenuGroup title="订单信息管理">
        <MenuItem name="4"
                  to="/dingDanShow">
          <Icon type="md-heart"/>
          个人订单
        </MenuItem>
        <MenuItem name="5">


        </MenuItem>
        <MenuItem name="6">

        </MenuItem>
        <!-- <MenuItem name="7">

        </MenuItem>
        <MenuItem name="8">

        </MenuItem> -->

      </MenuGroup>
      <MenuGroup title="管理员">
        <MenuItem
            to="/managerLogin"
            name="9"
        >
          <Icon type="md-document"/>
          管理员登陆
        </MenuItem>
        <MenuItem
            name="10"
            to="/addObject"
        >
          <Icon type="md-chatbubbles"/>
          修改信息
        </MenuItem>
        <MenuItem
            name="11"
            to="/memberList"
        >
          <Icon type="md-chatbubbles"/>
          会员信息查看
        </MenuItem>
      </MenuGroup>
      <MenuGroup title="登陆管理">
        <MenuItem
            name="12"
            to="/memberLogin"
        >
          <Icon type="md-document"/>
          会员登陆（注册）
        </MenuItem>
        <MenuItem name="13">
          <Icon type="md-chatbubbles"/>
          账号退出
        </MenuItem>
        <MenuItem name="14">
          <Icon type="md-beer"/>
          账号注销
        </MenuItem>
      </MenuGroup>
    </Menu>
  </div>
</template>

<script>
// import PaneList from '@/components/PaneList.vue'
export default {
  name: "NavBar",
  data() {
    return {}
  },
  components: {
    // PaneList
  },
  methods: {}
}
</script>

<style scoped>

</style>