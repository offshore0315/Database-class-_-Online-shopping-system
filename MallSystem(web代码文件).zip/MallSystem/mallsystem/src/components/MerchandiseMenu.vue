<template>
  <div class="object" @click="lookObjectDetails">
    <span class="img">
      <img
        :src="object.pictures[0]"
        alt=""
        width="200px"
        height="200px"
        style="border-radius: 10px"
      />
    </span>
    <span class="main">
      <el-tag type="danger" style="margin-left: 5px; margin-top: 5px">{{
        object.name
      }}</el-tag>
      <span class="introduce">
        <h3>{{ object.introduce | ellipsis }}</h3>
      </span>
      <span class="tag">
        <el-tag type="success" style="font-size: 8px">包邮</el-tag>
        <el-tag type="success" style="font-size: 8px">极速退款</el-tag>
        <el-tag type="success" style="font-size: 8px">正品保证</el-tag>
      </span>
      <span class="price">
        ￥{{ object.price }}
        <el-button
          type="primary"
          plain
          style="float: right; margin-top: 5px; margin-right: 10px"
          @click.stop="addShopCar"
          >立即加入购物车</el-button
        >
      </span>
    </span>
    <Drawer
      title="商品详细信息"
      :closable="true"
      v-model="drawer"
      @draggable="true"
      width="80vh"
    >
      <ShopShowPage :goods="this.object" />
    </Drawer>
  </div>
</template>

<script>
import ShopShowPage from "@/components/ShopShowPage.vue";
import axios from "axios";
export default {
  props: ["object"],
  data() {
    return {
      drawer: false,
    };
  },
  components: {
    ShopShowPage,
  },
  methods: {
    addShopCar() {
      if (this.$store.state.HeaderView.LoginStatus.status) {
        axios({
          url: "http://127.0.0.1:8090/ShoppingCart/insert",
          method: "POST",
          data: {
            Hno: this.$store.state.HeaderView.LoginStatus.user_id,
            Sno: this.object.id,
          },
        }).then(
          (res) => {
            console.log(res.data);
            if(res.data.status === 200){
              this.$message.success("添加成功");
            }else {
              this.$message.error("添加失败");
            }
          },
          (err) => {
            console.log(err);
            this.$message.error("添加失败");
          }
        );
      } else {
        this.$message.error("未登陆不可使用");
        this.drawer = false
        console.log(this.drawer);
      }
    },
    lookObjectDetails() {
      this.drawer = true;
    },
  },
  filters: {
    ellipsis(value) {
      if (!value) return "";
      if (value.length > 50) {
        return value.slice(0, 50) + "...";
      }
      return value;
    },
  },
};
</script>

<style scoped>
.object {
  display: inline-block;
  width: 49%;
  margin-left: 0.5%;
  margin-top: 5px;
  border-radius: 5px;
  height: 200px;
  background-color: rgb(205, 217, 221);
}
.img {
  float: left;
  width: 200px;
}
.main {
  float: left;
  width: calc(100% - 200px);
  height: 100%;
  border-radius: 10px;
}
.introduce {
  float: left;
  width: 100%;
  height: 20%;
  padding-left: 5px;
  padding-right: 5px;
  padding-top: 5px;
  font-weight: 700;
}
.tag {
  float: left;
  width: 90%;
  height: 20%;
  margin-top: 15px;
  margin-left: 1%;
}
.price {
  float: left;
  width: 96%;
  border-radius: 10px;
  height: 25%;
  margin-top: 4%;
  margin-left: 2%;
  background-color: rgb(227, 158, 90);
  color: #ffffff;
  font-size: 28px;
}
</style>