<template>
    <div style="background-color: rgb(250, 250, 250)">
      <Poptip
        trigger="hover"
        word-wrap
        width="200"
        title="商品介绍"
        :content="goods.introduce"
        placement="right"
      >
        <h1 style="color: #70a1ff">
          {{ goods.name }}
        </h1>
      </Poptip>
      <el-tag type="danger" style="margin-left: 10px; margin-top: 20px"
        >包邮</el-tag
      >
      <el-tag type="danger" style="margin-left: 10px; margin-top: 20px"
        >极速发货</el-tag
      >
      <el-tag type="danger" style="margin-left: 10px; margin-top: 20px"
        >正品保证</el-tag
      >
      <div class="loop_pictures">
        <el-carousel height="68vh">
          <el-carousel-item
            v-for="(item, index) in goods.pictures"
            :key="index"
            :loop="true"
            :interval=1500
          >
            <img
              :src="item"
              alt=""
              width="100%"
              height="100%"
              style="border-radius: 10px"
            />
          </el-carousel-item>
        </el-carousel>
      </div>
      <Poptip
        trigger="hover"
        word-wrap
        width="200"
        title="商品介绍"
        :content="goods.introduce"
        placement="right"
      >
        <div style="margin-top: 20px">
          <h1 style="color: red; font-size: 35px">￥{{ goods.price }}</h1>
        </div>
      </Poptip>
    </div>
  </template>
  
  <script>
  export default {
    name: "ShopShowPage",
    props: ["goods"],
    data() {
      return {
        loopValue: 0,
      };
    },
    methods: {
      
    },
  };
  </script>
  
  <style scoped>
  .loop_pictures {
    width: 100%;
    height: 60%;
    border-radius: 10px;
    margin-top: 20px;
    background-color: rgb(250, 250, 250);
  }
  </style>