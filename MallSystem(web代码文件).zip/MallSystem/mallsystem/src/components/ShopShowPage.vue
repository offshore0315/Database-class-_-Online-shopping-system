<template>
  <div style="background-color: rgb(250, 250, 250)">
    <Poptip
      trigger="hover"
      word-wrap
      width="200"
      title="商品介绍"
      :content="goods.introduce"
      placement="right"
    >
      <h1 style="color: #70a1ff">
        {{ goods.name }}
      </h1>
    </Poptip>
    <el-tag type="danger" style="margin-left: 10px; margin-top: 20px"
      >包邮</el-tag
    >
    <el-tag type="danger" style="margin-left: 10px; margin-top: 20px"
      >极速发货</el-tag
    >
    <el-tag type="danger" style="margin-left: 10px; margin-top: 20px"
      >正品保证</el-tag
    >
    <div class="loop_pictures">
      <el-carousel height="68vh">
        <el-carousel-item
          v-for="(item, index) in goods.pictures"
          :key="index"
          :loop="true"
          :interval=1500
        >
          <img
            :src="item"
            alt=""
            width="100%"
            height="100%"
            style="border-radius: 10px"
          />
        </el-carousel-item>
      </el-carousel>
    </div>
    <Poptip
      trigger="hover"
      word-wrap
      width="200"
      title="商品介绍"
      :content="goods.introduce"
      placement="right"
    >
      <div style="margin-top: 20px">
        <h1 style="color: red; font-size: 35px">￥{{ goods.price }}</h1>
        <el-button
          type="primary"
          plain
          style="float: right; margin-top: 5px; margin-right: 10px"
          @click="addShopCar"
          >立即加入购物车</el-button
        >
      </div>
    </Poptip>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: "ShopShowPage",
  props: ["goods"],
  data() {
    return {
      loopValue: 0,
    };
  },
  methods: {
    addShopCar() {
      if (this.$store.state.HeaderView.LoginStatus.status) {
        axios({
          url: "http://127.0.0.1:8090/ShoppingCart/insert",
          method: "POST",
          data: {
            Hno: this.$store.state.HeaderView.LoginStatus.user_id,
            Sno: this.goods.id,
          },
        }).then(
          (res) => {
            console.log(res.data);
            if(res.data.status === 200){
              this.$message.success("添加成功");
            }else {
              this.$message.error("添加失败");
            }
          },
          (err) => {
            console.log(err);
            this.$message.error("添加失败");
          }
        );
      } else {
        this.$message.error("未登陆不可使用");
        this.drawer = false
        console.log(this.drawer);
      }
    },
  },
};
</script>

<style scoped>
.loop_pictures {
  width: 100%;
  height: 60%;
  border-radius: 10px;
  margin-top: 20px;
  background-color: rgb(250, 250, 250);
}
</style>