<template>
  <div>
    <Space size="large">
      <Avatar
          shape="square"
          :style="AvatarStyle"
          icon="logo-twitter"
          size="large"
      />
    </Space>
    <span class="user_name">{{ this.$store.state.HeaderView.LoginStatus.user_name }}</span>

    <el-breadcrumb style="display: inline-block; margin-left: 60px">
      <el-breadcrumb-item
          v-for="(item,index) in this.$store.state.HeaderView.PathCrumb"
          :key="index"
      >{{ item }}
      </el-breadcrumb-item>
    </el-breadcrumb>

    <el-dropdown
        style="margin-right: 200px; float: right; font-size: 15px"
        @command="goToIndex"
    >
      <span class="el-dropdown-link">
        下拉菜单<i class="el-icon-arrow-down el-icon--right"></i>
      </span>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item  command="a">商城主页</el-dropdown-item>
        <el-dropdown-item  command="b">我的购物车</el-dropdown-item>
        <el-dropdown-item  command="c">我的订单</el-dropdown-item>
        <el-dropdown-item   disabled>系统服务</el-dropdown-item>
        <el-dropdown-item  command="d" >初始页</el-dropdown-item>
        <el-dropdown-item  command="e" divided>退出登陆</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
  </div>
</template>

<script>
export default {
  name: "HeaderView",
  data() {
    return {
      AvatarStyle: "background-color: #b4b1b1",
      LoginStatus: this.$store.state.HeaderView.LoginStatus.status
    }
  },
  methods: {
    changeAvatarStyle(color) {
      this.AvatarStyle = "background-color: " + color
    },
    goToIndex(event) {
      if(event === "d"){
        this.$router.push(
            {
              path: "/"
            }
        )
      } else if(event === 'e'){
        this.$store.commit("logoutUser")
      } else if(event === 'a'){
        this.$router.push(
            {
              path: "/shopView"
            }
        )
      } else if(event === 'b'){
        this.$router.push(
            {
              path: "/shopCar"
            }
        )
      } else if(event === 'c'){
        this.$router.push(
            {
              path: "/dingDanShow"
            }
        )
      }
    }
  },
  watch: {
    '$store.state.HeaderView.LoginStatus.status'() {
      if (this.$store.state.HeaderView.LoginStatus.status) {
        this.changeAvatarStyle("#87d068")
      } else {
        this.changeAvatarStyle("#b4b1b1")
      }
    }
  },
  mounted() {
    if (this.$store.state.HeaderView.LoginStatus.status) {
      this.changeAvatarStyle("#87d068")
    } else {
      this.changeAvatarStyle("#b4b1b1")
    }
  }
}
</script>

<style scoped>
.user_name {
  font-size: 20px;
  margin-left: 25px;
  color: #57541d;
  font-family: 宋体, serif;
}
</style>