<template>
  <div class="list_pane">
    <h1>你好购物车</h1>
  </div>
</template>

<script>
export default {
  name: "PaneList"
}
</script>

<style scoped>
.list_pane {
  width: 100%;
  height: 10vh;
  background-color: #ecb0c1;
  /*border-radius: 5px;*/
}
</style>