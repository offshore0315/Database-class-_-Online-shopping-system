import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
    //数据存放
    state: {
        HeaderView: {
            // 登陆状态
            // "LoginStatus": {
            //     status: true,
            //     user: "member",
            //     user_id:"13207",
            //     user_pwd: "xinan2002",
            //     user_name: "华电",
            // },
            "LoginStatus": {
                status: false,
                user: "",
                user_id:"",
                user_pwd: "",
                user_name: "",
            },
            "PathCrumb": [
                "首页",
            ]
        }
    },
    getters: {},
    // 数据修改函数
    mutations: {
        loginUser(state, data) {
            state.HeaderView.LoginStatus = {
                status: true,
                user_id:data.id,
                user:data.user,
                user_pwd: data.pwd,
                user_name: data.name
            }
        },
        logoutUser(state) {
            state.HeaderView.LoginStatus = {
                status: false,
                user_id:"",
                user:"",
                user_pwd: "",
                user_name: "***"
            }
        },
        changePathCrumb(state,array) {
            state.HeaderView.PathCrumb = array
        }
    },
    actions: {},
    modules: {}
})
