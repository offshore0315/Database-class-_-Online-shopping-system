/**
 * @name routerMember
 * @author MateBook13
 * @description routerMember
 * @date 2023/1/8
 */
const express = require('express')
const router = express.Router()
const log4js = require('log4js')
let logger = log4js.getLogger("mallsystem");
logger.level = 'info'

const mysql = require('mysql')
// mysql 配置信息
const config = {
    host: "rm-2ze81g5572t0v2231zo.mysql.rds.aliyuncs.com",
    user: "messi",
    password: "Xinan2002@",
    port: "3306",
    database: "mall_system"//需要操作的数据库
};
const db = mysql.createPool(config)


router.post('/select', (req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    const body = req.body
    let sql = `SELECT *
FROM huiyuan;`;
    db.query(sql, (err, results) => {
        if (err) return console.log(err.message);
        res.send({
            status: 200,
            msg: "登陆成功",
            data: {
                status: "success",
                body: results
            }
        })
    })
})
router.post('/login', (req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    const body = req.body
    logger.info(body.name)
    let sql = `SELECT Hpassword,Hno FROM huiyuan WHERE Hname = '` + body.name + `';`;
    db.query(sql, (err, results) => {
        if (err) return console.log(err.message);
        logger.info(results[0].Hpassword);
        if (results[0].Hpassword === body.password) {
            logger.info("正确")
            res.send({
                status: 200,
                msg: "登陆成功",
                data: {
                    status: "success",
                    body: results
                }
            })
        } else {
            res.send({
                status: 403,
                msg: "用户名或密码错误",
                data: {
                    status: "error"
                }
            })
        }
    })
})

router.post('/register', (req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    const body = req.body
    logger.info(body)
    let arr = ""
    for (let i = 0; i < 5; i++) {
        let ran = Math.floor((Math.random() * 10))
        arr += ran;
    }
    let sql = `INSERT INTO huiyuan VALUES (?,?,?,?,?);`;
    db.query(sql, [arr, body.Hname, body.Hpassword, body.Htel, body.Hadd], (err, results) => {
        if (err) {
            res.send({
                status: 403,
                msg: "注册错误",
                data: {
                    status: "error"
                }
            })
        } else {
            res.send({
                status: 200,
                msg: "注册成功",
                data: {
                    status: "success"
                }
            })
        }
        logger.info("注册新会员", results)
    })
})

module.exports =
    router