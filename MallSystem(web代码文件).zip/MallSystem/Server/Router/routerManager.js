/**
 * @name routerManager
 * @author MateBook13
 * @description routerManager
 * @date 2023/1/14
 */
const express = require('express')
const router = express.Router()
const log4js = require('log4js')
let logger = log4js.getLogger("mallsystem");
logger.level = 'info'

const mysql = require('mysql')
// mysql 配置信息
const config = {
    host: "rm-2ze81g5572t0v2231zo.mysql.rds.aliyuncs.com",
    user: "messi",
    password: "Xinan2002@",
    port: "3306",
    database: "mall_system"//需要操作的数据库
};
const db = mysql.createPool(config)

router.post('/login', (req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    const body = req.body
    logger.info(body.name)
    let sql = `SELECT GLpassword FROM gly WHERE GLno = ?`;
    db.query(sql,[body.number], (err, results) => {
        if (err) return console.log(err.message);
        logger.info(results[0].GLpassword);
        if(results[0].GLpassword === body.password){
            logger.info("正确")
            res.send({
                status: 200,
                msg: "登陆成功",
                data: {
                    status:"success"
                }
            })
        }else {
            res.send({
                status: 403,
                msg: "用户名或密码错误",
                data: {
                    status:"error"
                }
            })
        }
    })
})



module.exports =
    router