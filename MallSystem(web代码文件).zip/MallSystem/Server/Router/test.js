/**
 * @name test
 * @author MateBook13
 * @description test
 * @date 2023/1/16
 */

let d =new Date();
let _id = d.getHours()+""+d.getMinutes()+""+d.getSeconds()+""+d.getMilliseconds()
console.log(_id)
