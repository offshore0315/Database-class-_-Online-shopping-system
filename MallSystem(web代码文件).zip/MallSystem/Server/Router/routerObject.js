/**
 * @name routerObject
 * @author MateBook13
 * @description routerObject
 * @date 2023/1/16
 */
const express = require('express')
const router = express.Router()
const fs = require('fs')
const path = require('path')
const multer = require('multer')
const log4js = require('log4js')
let logger = log4js.getLogger("mallsystem");
logger.level = 'info'

const mysql = require('mysql')
// mysql 配置信息
const config = {
    host: "rm-2ze81g5572t0v2231zo.mysql.rds.aliyuncs.com",
    user: "messi",
    password: "Xinan2002@",
    port: "3306",
    database: "mall_system"//需要操作的数据库
};
const db = mysql.createPool(config)


router.post('/add', (req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    const body = req.body
    let sql = ``;
    db.query(sql, [], (err, results) => {
        if (err) return console.log(err.message);
        res.send({
            status: 200,
            msg: "登陆成功",
            data: {
                status: "success",
                body: results
            }
        })
    })
})

router.post('/addPicture', (req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    const body = req.body
    let _type = req.files.number.type.split('/')
    fs.writeFileSync(path.join(__dirname, "../Temp/" + Date.now() + "." + _type[1]), fs.readFileSync(req.files.number.path), "utf8")
    res.send(req.files)
    let sql = `INSERT INTO object_pictures
VALUES (?, ?);`;
    db.query(sql, [body.Sno, path.join(__dirname, "../Temp/" + Date.now() + "." + _type[1])], (err, results) => {
        if (err) return console.log(err.message);
        res.send({
            status: 200,
            msg: "登陆成功",
            data: {
                status: "success",
                body: results
            }
        })
    })
})


module.exports =
    router