const express = require('express')
const router = express.Router()

router.get('/get', (req, res) => {
    const query = req.query
    res.send({
        status: 0,
        msg: "GET成功",
        data: query
    })
})

router.post('/world_cup', (req, res) => {
    const body = req.body
    res.send({
        status: 0,
        msg: "POST成功",
        data: body
    })
})

router.delete('/world_cup', (req, res) => {
    const body = req.body
    res.send({
        status: 0,
        msg: "POST成功",
        data: body
    })
})

router.put('/world_cup', (req, res) => {
    const body = req.body
    res.send({
        status: 0,
        msg: "POST成功",
        data: body
    })
})

module.exports =
    router